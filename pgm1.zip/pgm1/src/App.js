import logo from './logo.svg';
import './App.css';
import Intro from'./intro.js';

function App() {
  return (
    <Intro />
  );
}

export default App;
