import React, { Component } from 'react'

export default class intro extends Component {
    render() {
        return (
            <div>
                <div>
                    <h1> 
                        Resume
                    </h1>
                </div>
            </div>
        )
    }
}
