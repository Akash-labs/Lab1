package com.example.program5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    Button btn1,btn2;
    EditText user,pass;
    DBHelper dbh;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        user = findViewById(R.id.editTextTextPersonName);
        pass = findViewById(R.id.editTextTextPersonName2);
        btn1 = findViewById(R.id.button);
        btn2 = findViewById(R.id.button2);

        dbh = new DBHelper(this);
        btn1.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Boolean res = dbh.validate(user.getText().toString(),pass.getText().toString());
            if(res){
                String Users = user.getText().toString();
                Intent intent = new Intent(MainActivity.this,MainActivity2.class);
                intent.putExtra("Username",Users);
                startActivity(intent);
            }else{
                Toast.makeText(getApplicationContext(), "wrong id or password", Toast.LENGTH_SHORT).show();
            }
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Boolean res = dbh.register(user.getText().toString(),pass.getText().toString());
                if(res){
                    Toast.makeText(getApplicationContext(), "USER CREATED NOW LOGIN", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(getApplicationContext(), "USER Already exist", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}