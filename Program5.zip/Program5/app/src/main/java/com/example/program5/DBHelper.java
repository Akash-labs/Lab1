package com.example.program5;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    DBHelper(Context c){super(c,"nehash",null,1);}

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table nehash(user TEXT,pass TEXT);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists nehash");
    }
    public Boolean validate(String user,String pass){
        SQLiteDatabase db= this.getReadableDatabase();
        Cursor c=db.rawQuery("select * from nehash where user=? and pass=?",new String[]{user,pass});
        if(c.getCount()>0){
            return true;
        }else {
            return false;
        }
    }
    public Boolean register(String user,String pass){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("user",user);
        cv.put("pass",pass);


        Cursor  c=db.rawQuery("SELECT * FROM nehash where user=? and pass=?",new String[]{user,pass});
        if(c.getCount()>0){
            return false;
        }else {
            db.insert("nehash",null,cv);
            return true
                    ;
        }
    }

}
